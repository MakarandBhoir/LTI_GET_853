import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-a',
  templateUrl: './a.component.html',
  styleUrls: ['./a.component.css']
})
export class AComponent implements OnInit {
  studentForm: FormGroup;

  
  constructor(private router:Router, private fb: FormBuilder) { }

  ngOnInit() {
    this.studentForm = this.fb.group({
      studentName: ['', Validators.required],
      email: ['', Validators.required]
      
    });
  }
  callOtherComponent():void{
    this.router.navigate(['gotoB', this.studentForm.controls.studentName.value, 
          this.studentForm.controls.email.value]);
  }
}
