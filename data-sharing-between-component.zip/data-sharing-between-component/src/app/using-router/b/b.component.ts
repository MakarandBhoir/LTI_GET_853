import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-b',
  templateUrl: './b.component.html',
  styleUrls: ['./b.component.css']
})
export class BComponent implements OnInit {

  username:string;
  email:string;
  constructor(private router:Router, private router2:ActivatedRoute) { }

  ngOnInit() {
    this.username = this.router2.snapshot.paramMap.get('user');
    this.email = this.router2.snapshot.paramMap.get('email');
  }

}
