import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AComponent } from './using-router/a/a.component';
import { BComponent } from './using-router/b/b.component';


const routes: Routes = [
  { path: 'gotoA', component: AComponent },
  { path: 'gotoB/:user/:email', component: BComponent },
  { path: '', component: AComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
