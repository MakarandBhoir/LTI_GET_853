package chapter2.basic;

public class Array {
	private int[] items;
	private int count;
	
	public Array(int length) {
		items = new int[length];
	}
	public void add(int item) {
		// if array is full then resize it by re-creating new array
		if(getCapacity() == getSize()) {
			// create new array with double capacity
			int newItems[] = new int[getCapacity()*2];
			
			// copy all the existing items
			for(int i=0; i<getCapacity(); i++) {
				newItems[i] = items[i];
			}
			
			// point items to new array
			items = newItems;
		}
		items[count++] = item;
	}
	public void remove(int index) {
		// validate index whether it is negative or greater than size of the array
		if(index<0 || index >= getSize()) {
			throw new IllegalArgumentException("Invalid index = "+index);
		}
		// shift items to left to fill deleted item
		for(int i=index; i<getSize(); i++) {
			items[i] = items[i+1];
		}
		count--;
	}
	public int indexOf(int item) {
		// iterate over the loop
		for(int i=0; i<getSize(); i++) {
			// if item found in array then return current index of array
			if(item == items[i]) {
				return i;
			}
		}
		// if item is not found in array then return -1
		return -1;
	}
	public void print() {
		System.out.print("[ ");
		for(int i=0; i < getSize(); i++) {
			System.out.print(items[i]+" ");
		}
		System.out.println("]");
	}
	public int getSize() {
		return count;
	}
	public int getCapacity() {
		return items.length;
	}
}
