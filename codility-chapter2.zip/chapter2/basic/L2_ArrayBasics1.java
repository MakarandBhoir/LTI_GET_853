package chapter2.basic;

public class L2_ArrayBasics1 {
	public void iterate(int A[]) {
		System.out.print("[ ");
		for(int i=0; i<A.length; i++) {
			System.out.print(A[i]+" ");
		}
		System.out.println("]");
	}
	public static void main(String[] args) {
		int A[] = new int[7];
		A[0] = 10;
		A[1] = 70;
		A[2] = 20;
		A[3] = 60;
		A[4] = 30;
		A[5] = 40;
		A[6] = 50;
		
		new L2_ArrayBasics1().iterate(A);
	}
}
