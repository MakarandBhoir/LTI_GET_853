package chapter2.basic;

public class L2_ArrayBasics4 {
	public static void main(String[] args) {
		try {
			Array arr = new Array(4);
			System.out.println("Size: " + arr.getSize() + ", Capacity: " + arr.getCapacity());
			arr.add(10);
			arr.add(20);
			System.out.println("Size: " + arr.getSize() + ", Capacity: " + arr.getCapacity());
			arr.remove(1);
			System.out.println("Size: " + arr.getSize() + ", Capacity: " + arr.getCapacity());
			arr.print();
			// System.out.println("Index for 20: " + arr.indexOf(201));
			arr.add(77);
			arr.print();
			System.out.println("Size: " + arr.getSize() + ", Capacity: " + arr.getCapacity());
		} catch (IllegalArgumentException e) {
			System.out.println(e.getMessage());
		}
	}
}
