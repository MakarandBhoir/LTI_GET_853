package chapter2.basic;

public class L2_ArrayBasics3 {
	public void iterate(int A[]) {
		System.out.print("[ ");
		for(int i=0; i<A.length; i++) {
			System.out.print(A[i]+" ");
		}
		System.out.println("]");
	}
	public int[] reverse(int A[]) {
		int N = A.length;
		for(int i=0; i<N/2; i++) {
			int k = N - i -1;
			
			A[i] = A[i] + A[k];
			A[k] = A[i] - A[k];
			A[i] = A[i] - A[k];
		}
		return A;
	}
	public static void main(String[] args) {
		int A[] = new int[7];
		A[0] = 10;
		A[1] = 20;
		A[2] = 30;
		A[3] = 40;
		A[4] = 50;
		A[5] = 60;
		A[6] = 70;
		L2_ArrayBasics3 obj = new L2_ArrayBasics3();
		obj.iterate(A);
		obj.reverse(A);
		obj.iterate(A);
		
		
	}
}
