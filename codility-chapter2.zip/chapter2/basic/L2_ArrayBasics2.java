package chapter2.basic;

public class L2_ArrayBasics2 {
	public int negative(int tempratures[]) {
		int days = 0;
		for(int i=0; i<tempratures.length; i++)
			if(tempratures[i] < 0)
				days +=1;
		return days;
	}
	public static void main(String[] args) {
		int year[] = new int[365];
		int max=50;
		int min=-20;
		for(int i=0; i<365; i++) {
			year[i] = ((int)(Math.random()*(max-min)))+min;
		}
		System.out.println("Days with negative temprature: "+new L2_ArrayBasics2().negative(year));
	}
}
