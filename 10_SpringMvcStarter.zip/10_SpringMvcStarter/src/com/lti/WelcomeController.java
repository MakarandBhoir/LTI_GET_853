package com.lti;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller("welcome")
public class WelcomeController {
	
	// http://localhost:9091/10_SpringMvcStarter/welcome.do
	@RequestMapping(path="welcome.do", method=RequestMethod.GET)
	public String welcome() {
		System.out.println("welcome controller is called.");
		return "welcome.jsp";
	}
}
