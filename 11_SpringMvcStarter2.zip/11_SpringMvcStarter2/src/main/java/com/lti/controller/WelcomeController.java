package com.lti.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class WelcomeController {
	
	// http://localhost:9091/11_SpringMvcStarter2/
	@RequestMapping(path="/", method=RequestMethod.GET)
	public String home() {
		System.out.println("home controller");
		return "index"; // WEB-INF/pages/index.jsp
	}
	
	// http://localhost:9091/11_SpringMvcStarter2/welcome.do
	@RequestMapping(path="welcome.do", method=RequestMethod.GET)
	public String welcome() {
		System.out.println("welcome controller");
		return "welcome";
	}
	
}
