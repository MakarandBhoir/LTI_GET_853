import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Employee } from '../employee';
import { EmployeeModule } from '../employee.module';

@Component({
  selector: 'emp-form',
  templateUrl: './emp-form.component.html',
  styleUrls: ['./emp-form.component.css']
})
export class EmpFormComponent implements OnInit {
  employeeForm:FormGroup;
  //FormGroup & FormControl
  //employees:Employee[] = [];
  employees:Employee[] = new Array();

  constructor() { }

  ngOnInit() {
    this.employeeForm = new FormGroup({
      employeeId: new FormControl(),
      employeeName: new FormControl(),
      employeeSalary: new FormControl()
    });
  }
  // showEmployee():void{
  //   alert("showEmployee");
  //   console.log(this.employeeForm.controls.employeeId.value);
  //   console.log(this.employeeForm.controls.employeeName.value);
  //   console.log(this.employeeForm.controls.employeeSalary.value);
  // }

  showEmployee():void{
    let emp:Employee = new Employee(this.employeeForm.controls.employeeId.value, 
                                    this.employeeForm.controls.employeeName.value,
                                    this.employeeForm.controls.employeeSalary.value);
    this.employees.push(emp);
  }
}
