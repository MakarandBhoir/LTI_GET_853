export class Employee{
    employeeId:number;
    employeeName:string;
    employeeSalary:number;

    constructor(id:number, name:string, salary:number){
        this.employeeId = id;
        this.employeeName = name;
        this.employeeSalary = salary;
    }
    toString():string{
        return "Id: "+this.employeeId+", Name: "+this.employeeName+", Salary:"+this.employeeSalary;
    }
}