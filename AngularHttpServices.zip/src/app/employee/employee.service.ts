import { Injectable } from '@angular/core';
import { Employee } from './employee';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  // in-memory database. data is going to lost after restart of server
  // static employees:Employee[];
  constructor(private http:HttpClient) { 
  }

  addEmployee(emp:Employee):Observable<Object>{
    alert(JSON.stringify(emp));
    return this.http.post("http://localhost:3000/employees", emp);
  }
  getAllEmployees():Observable<Employee[]>{
    // the result of get function. get fun will give you Observable<Employee[]>
    return this.http.get<Employee[]>("http://localhost:3000/employees");
  }
}
// post - create new employee
// get - read existing employee
// put - updating existing employee
// delete - delete existing employee