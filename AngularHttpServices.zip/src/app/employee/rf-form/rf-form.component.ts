import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'rf-form',
  templateUrl: './rf-form.component.html',
  styleUrls: ['./rf-form.component.css']//,
  //providers:[EmployeeService]
})
export class RfFormComponent implements OnInit {
  employeeForm: FormGroup;
  employees: Employee[];

  // fb:FormBuilder;
  // service:EmployeeService
  // constructor(fb:FormBuilder, service:EmployeeService) { 
  //   this.fb = fb;
  //   this.service = service;
  // }

  constructor(private fb: FormBuilder, private service:EmployeeService) {
       this.employees = new Array();
  }

  ngOnInit() {
    console.log("ng on init");
    this.employeeForm = this.fb.group({
      employeeId: ['', Validators.required],
      employeeName: ['', Validators.required],
      employeeSalary: ['', Validators.required]
    });

    this.service.getAllEmployees().subscribe(data=>{
         this.employees = data;
       });
  }
  addEmployee(): void {
    let emp: Employee = new Employee(this.employeeForm.controls.employeeId.value,
      this.employeeForm.controls.employeeName.value,
      this.employeeForm.controls.employeeSalary.value);
    //this.employees.push(emp);
    //this.employees = this.service.addEmployee(emp);
    this.service.addEmployee(emp).subscribe(data =>{
      alert("data: "+JSON.stringify(data));
      this.employees.push(emp);
    });
  }
}
