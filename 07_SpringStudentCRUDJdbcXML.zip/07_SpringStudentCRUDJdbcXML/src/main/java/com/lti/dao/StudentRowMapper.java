package com.lti.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.jdbc.core.RowMapper;

import com.lti.model.Address;
import com.lti.model.Student;
import com.lti.ui.Main;
import com.lti.ui.Main2;

public class StudentRowMapper implements RowMapper<Student>{
	
	@Override
	public Student mapRow(ResultSet rs, int rowNum) throws SQLException {
		/*
		 * Student student = new Student(); Address address = new Address();
		 * student.setAddress(address);
		 */
		ApplicationContext context = Main2.getContext();
		
		Student student = context.getBean("student", Student.class);
		
		student.setStudentId(rs.getInt("STUDENT_ID"));
		student.setStudentName(rs.getString("STUDENT_NAME"));
		student.setScore(rs.getDouble("STUDENT_SCORE"));
		
		student.getAddress().setCity(rs.getString("CITY"));
		student.getAddress().setState(rs.getString("STATE"));
		student.getAddress().setPin(rs.getString("PIN"));
		
		return student;
	}

}
