package com.lti.service;

import java.util.List;

import com.lti.dao.StudentDao;
import com.lti.model.Student;

public class StudentServiceImpl implements StudentService{
	//StudentDaoImpl dao = new StudentDaoImpl();
	//StudentDao dao = new StudentDaoImpl();
	
	// Object will be created by spring framework & will be injected here
	private StudentDao dao = null;
	
	@Override
	public boolean addStudent(Student student) {
		int result = dao.createStudent(student);
		return (result == 1)? true : false;
	}
	@Override
	public List<Student> findAllStudents() {
		return dao.readAllStudents();
	}
	@Override
	public boolean modifyStudent(Student student) {
		int result = dao.updateStudent(student);
		return (result == 1)? true : false;
	}
	@Override
	public boolean removeStudent(int studentId) {
		int result = dao.deleteStudent(studentId);
		return (result == 1)?true : false;
	}
	
	public StudentDao getDao() {
		return dao;
	}
	public void setDao(StudentDao dao) {
		this.dao = dao;
	}
}
