package com.lti.ui;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.model.Student;
import com.lti.service.StudentService;

public class Main2 {
	
	private static ApplicationContext context;
	
	public static void main(String[] args) {

		context = new ClassPathXmlApplicationContext("spring-config.xml");

		StudentService service = getContext().getBean("service", StudentService.class);
		Student student = getContext().getBean("student", Student.class);
		
		student.setStudentId(70);
		student.setStudentName("Abhinav");
		student.setScore(70.0);
		student.getAddress().setCity("Chandigrh");
		student.getAddress().setState("Punjab");
		student.getAddress().setPin("166012");

		boolean result = service.modifyStudent(student);
		if (result) {
			System.out.println("Student is updated.");

			List<Student> students = service.findAllStudents();
			for (Student s : students) {
				System.out.println(s);
				System.out.println(s.getAddress());
			}

		}
	}
	public static ApplicationContext getContext() {
		return context;
	}
	public static void setContext(ApplicationContext context) {
		Main2.context = context;
	}
}
