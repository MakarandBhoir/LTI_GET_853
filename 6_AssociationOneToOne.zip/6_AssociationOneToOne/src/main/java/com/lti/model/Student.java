package com.lti.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.NotFound;

@Entity
@Table(name="STUDENT_TBL")
public class Student implements Serializable {
	@Id
	@Column(name="roll_number")
	private int rollNumber;
	
	@Column(name="student_name")
	private String studentName;
	
	@Column(name="score")
	private double score;
	
	@Transient
	private String dateOfBirth;
	
	// Owner table
	// default name of FK -> homeaddress_address_id
	@OneToOne
	@JoinColumn(name="address_id")
	private Address homeAddress;
	
	public Student() {
		
	}
	public Student(int rollNumber, String studentName, double score) {
		super();
		this.rollNumber = rollNumber;
		this.studentName = studentName;
		this.score = score;
	}
	public int getRollNumber() {
		return rollNumber;
	}
	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", studentName=" + studentName + ", score=" + score + "]";
	}
	public String getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public Address getHomeAddress() {
		return homeAddress;
	}
	public void setHomeAddress(Address homeAddress) {
		this.homeAddress = homeAddress;
	}
	
}
