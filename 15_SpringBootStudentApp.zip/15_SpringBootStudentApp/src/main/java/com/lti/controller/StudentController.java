package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Student;
import com.lti.service.StudentService;

@RestController
@RequestMapping(path="students")
@CrossOrigin
public class StudentController {
	@Autowired
	private StudentService service;
	
	// http://localhost:9091/StudentApp/students/
	@GetMapping(path="/")
	public List<Student> getAllStudents(){
		List<Student> students = service.findAllStudents();
		return students;
	}
	
	// http://localhost:9091/StudentApp/students/10
	@GetMapping(path="{studentId}")
	public Student getStudentById(@PathVariable("studentId") int studentId) {
		return service.findStudentById(studentId);
	}
	
	// http://localhost:9091/StudentApp/students
	@PostMapping(path="/")
	public void addStudent(@RequestBody Student student) {
		service.addStudent(student);
	}
	
	// http://localhost:9091/StudentApp/students/160
	@DeleteMapping(path="{studentId}")
	public void deleteStudentByStudentId(@PathVariable("studentId") int studentId) {
		service.removeStudent(studentId);
	}

	// http://localhost:9091/StudentApp/students/
	@PutMapping(path="/")
	public Student updateStudent(@RequestBody Student student) {
		boolean result = service.modifyStudent(student);
		if(result)
			student = service.findStudentById(student.getStudentId());
		return student;
	}
	
}



