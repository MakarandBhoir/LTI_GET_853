package com.lti.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

@Configuration
@ComponentScan(basePackages= {"com.lti"})
public class AppConfig {
	@Autowired
	private DataSource dataSource;
	
	@Bean
	public JdbcTemplate getTemplate() {
		JdbcTemplate template = new JdbcTemplate();
		template.setDataSource(dataSource);
		return template;
	}
	
	@Bean
	public DataSource getDataSource1() {
		DriverManagerDataSource ds = new DriverManagerDataSource();
		ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		ds.setUrl("jdbc:oracle:thin:@localhost:1521:XE");
		ds.setUsername("makarand");
		ds.setPassword("makarand");
		return ds;
	}
	
	/*
	 * @Bean
	 * 
	 * @Primary public DataSource getDataSource2() { DriverManagerDataSource ds =
	 * new DriverManagerDataSource();
	 * ds.setDriverClassName("oracle.jdbc.driver.OracleDriver");
	 * ds.setUrl("jdbc:oracle:thin:@localhost:1521:XE"); ds.setUsername("prod");
	 * ds.setPassword("prod"); return ds; }
	 */
	
}
