package com.lti.ui;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.config.AppConfig;
import com.lti.model.Student;
import com.lti.service.StudentService;

public class Main {
	
	private static ApplicationContext context;
	
	public static void main(String[] args) {

		context = new AnnotationConfigApplicationContext(AppConfig.class);

		StudentService service = getContext().getBean("service", StudentService.class);
		Student student = getContext().getBean("student", Student.class);
		
		student.setStudentId(90);
		student.setStudentName("Test");
		student.setScore(89.50);
		student.getAddress().setCity("Mumbai");
		student.getAddress().setState("MH");
		student.getAddress().setPin("400706");

		boolean result = service.addStudent(student);
		if (result) {
			System.out.println("Student is added.");

			List<Student> students = service.findAllStudents();
			for (Student s : students) {
				System.out.println(s);
				System.out.println(s.getAddress());
			}

		}
	}
	public static ApplicationContext getContext() {
		return context;
	}
	public static void setContext(ApplicationContext context) {
		Main.context = context;
	}
}
