package com.lti.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.lti.model.Student;

/*
 Create Table Student
 (
 	Student_Id Number(5) Primary Key,
 	Student_Name Varchar2(35) Not Null,
 	Student_Score Number(5, 2) Not Null,
 	City Varchar2(45) Not Null,
 	State Varchar2(45) Not Null,
 	Pin Varchar2(10) Not Null
 )
 */
@Repository("dao")
@Scope(scopeName="singleton")
public class StudentDaoImpl_v2 implements StudentDao {
	// object will be created spring framework and injected here
	@Autowired(required=true)
	private JdbcTemplate template;

	private static final String ADD_STUDENT = "Insert Into STUDENT(STUDENT_ID, STUDENT_NAME, STUDENT_SCORE, CITY, STATE, PIN) VALUES(?, ?, ?, ?, ?, ?)";
	private static final String FIND_ALL_STUDENTS = "Select * From STUDENT";
	private static final String DELETE_STUDENT_BY_ID = "Delete From STUDENT Where STUDENT_ID = ?";
	private static final String UPDATE_STUDENT = "Update STUDENT set STUDENT_NAME = ?, STUDENT_SCORE = ?, CITY = ?, STATE = ?, PIN = ? Where STUDENT_ID = ?";

	@Override
	public int createStudent(Student student) {
		int result = template.update(ADD_STUDENT, student.getStudentId(), student.getStudentName(), student.getScore(),
				student.getAddress().getCity(), student.getAddress().getState(), student.getAddress().getPin());
		return result;
	}

	@Override
	public List<Student> readAllStudents() {
		List<Student> students = template.query(FIND_ALL_STUDENTS, new StudentRowMapper());
		return students;
	}

	@Override
	public int updateStudent(Student student) {
		int result = template.update(UPDATE_STUDENT, student.getStudentName(), student.getScore(),
				student.getAddress().getCity(), student.getAddress().getState(), student.getAddress().getPin(),
				student.getStudentId());
		return result;
	}

	@Override
	public int deleteStudent(int studentId) {
		int result = template.update(DELETE_STUDENT_BY_ID, studentId);
		return result;
	}
}
