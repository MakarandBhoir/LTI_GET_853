package chapter1.basics;

public class L1_WhileBasics {
	public static int digits(int num) {
		int result = 0;
		while(num>0) {
			num = num / 10;
			result ++;
		}
		return result;
	}
	public static void fibonacci(int num) {
		int a = 0;
		int b = 1;
		while(a <= num){
		   System.out.print(a + " ");
		   int c = a + b;
		   a = b;
		   b = c;
		}
	}
	public static void main(String[] args) {
		System.out.println("Number of digits: "+digits(123));
		fibonacci(21);
	}
}
