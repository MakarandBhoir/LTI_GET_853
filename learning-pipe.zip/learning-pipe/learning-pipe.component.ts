import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'learning-pipe',
  templateUrl: './learning-pipe.component.html',
  styleUrls: ['./learning-pipe.component.css']
})
export class LearningPipeComponent{
  text:string="learning pipe";
  price:number=100;
  today:Date = new Date();

  formats:string[] = [
    "dd/MM/yyyy",
    'dd/MM/yyyy hh:mm:ss',
    'dd-MM-yyyy',
    'dd-MM-yyyy hh:mm:ss',
    'MM/dd/yyyy',
    'MM/dd/yyyy hh:mm:ss',
    'yyyy/MM/dd',
    'yyyy/MM/dd HH:mm:ss',
    'dd/MM/yy',
    'dd/MM/yy hh:mm:ss',
  ];
}
