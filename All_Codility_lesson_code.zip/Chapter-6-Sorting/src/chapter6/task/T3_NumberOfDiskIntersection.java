package chapter6.task;

import java.util.Arrays;

public class T3_NumberOfDiskIntersection {
	public int solution(int []A) {
		// create two array to store upper and lower index
		long[] lower = new long[A.length];
		long[] upper = new long[A.length];
		
		//store the actual value in previous array
		for(int i=0; i<A.length; i++) {
			lower[i] = i - A[i];
			upper[i] = i + A[i];
		}
		
		//sort the arrays
		Arrays.sort(lower);
		Arrays.sort(upper);
		
		//count the total number of intersection points
		int count = 0;
		int j = 0;
		for(int i=0; i<A.length; i++) {
			while(j < A.length && upper[i] >= lower[j]) {
				count += j;
				count -= i;
				j++;
			}
		}
		if(count > 10000000)
			return -1;
		return count;
	}
	public static void main(String[] args) {

	}
}
