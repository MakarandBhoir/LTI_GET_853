package chapter6.task;

import java.util.Arrays;

public class T2_MaxOfThreeProduct {
	public int solution(int A[]) {
		// Find out 3 max values from array
		int N = A.length;
		// Sort the Array
		Arrays.sort(A); //[-5, -3, 1, 2, 6]
		// calculate product of those values
		int product  = A[N-1] * A[N-2] * A[N-3];
		// return product
		return product;
	}
	public int solution2(int A[]) {
		int N = A.length;
		// Sort the array
		Arrays.sort(A);
		// max1
		int max1 = A[N-1] * A[N-2] * A[N-3]; // 6 * 2 * 1 = 12
		int max2 = A[0] * A[1] * A[N-1]; // -5 * -3 * 6 = 90
		// find out max and return max
		return Math.max(max1, max2);
	}
	public static void main(String[] args) {
		//int A[] = {3, 2, 5, 6, 1};
		int A[] = {-3, 2, -5, 6, 1};
		System.out.println(new T2_MaxOfThreeProduct().solution2(A));
	}
}
