package chapter6.task;

import java.util.Arrays;
import java.util.HashSet;

public class T1_Distinct {
	public int solution(int A[]) {
		HashSet<Integer> set = new HashSet<>();
		for(int number : A)
			set.add(number);
		return set.size();
	}
	public int solution2(int A[]) {
		if(A==null ||A.length == 0) {
			return 0;
		}
		// Sort the array
		Arrays.sort(A);
		// check if current element and previous element if they are same you dont have to count
		int count = 1;
		for(int i=1; i<A.length; i++) {// i = 1, 2, 3
			int pre = A[i-1]; // 1, 1
			int curr = A[i]; // 1, 2
			if(pre != curr) {
				count++;
			}
		}
		// return the count
		return count;
	}
	public static void main(String[] args) {
		//int A[] = {1, 1, 1, 2, 3, 1};
		//int A[] = {1, 1, 2};
		int A[] = {2, 2};
		System.out.println(new T1_Distinct().solution2(A));
	}

}
