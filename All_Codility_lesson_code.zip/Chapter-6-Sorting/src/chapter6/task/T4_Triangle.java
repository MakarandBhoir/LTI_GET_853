package chapter6.task;

import java.util.Arrays;

public class T4_Triangle {
	public int solution(int A[]) {
		// 10, 5, 2
		// Sort the array
		Arrays.sort(A);// 2 5 10
		// Iterate over entire array
		for(int i=2; i<A.length; i++) {
		// A[i-2] + A[i-1] > A[i] return 1	
			if((long)A[i-2] + (long)A[i-1] > (long)A[i]) {
				return 1;
			}
		}
		return 0;
	}
	public static void main(String[] args) {

	}
}
