package chapter6.basic;

import java.util.Arrays;

public class SelectionSort {
	public int[] selectionSort(int A[]) {
		int n = A.length;
		for (int i = 0; i < n - 1; i++) 
		{
			int minimal = i;
			for (int j = i + 1; j < n; j++) 
			{
				if (A[j] < A[minimal]) 
				{
					int temp;
					temp = A[j];
					A[j] = A[minimal];
					A[minimal] = temp;
				}
			}
		}
		return A;
	}

	public static void main(String[] args) {
		int A[] = {5, 2, 8, 14, 1, 16};
		System.out.println(Arrays.toString(A));
		int B[] = new SelectionSort().selectionSort(A);
		System.out.println(Arrays.toString(B));
	}

}
