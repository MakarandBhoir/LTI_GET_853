package chapter6.basic;

import java.util.Arrays;

public class CountingSort {
	public int[] countingSort(int A[], int k) {
		int N = A.length;
		// it should store elements starting from 0 - 6
		int count[] = new int[k+1];
		//System.out.println(Arrays.toString(count));
		// storing count of every elements present in array A
		for(int i=0; i<N; i++) {
			count[A[i]]++;
		}
		//System.out.println(Arrays.toString(count));
		// prefix sum
		for(int i=1; i<=k; i++) {
			count[i] += count[i-1];
		}
		//System.out.println(Arrays.toString(count));
		
		int B[] = new int[N];
		// sorting the element using count array
		for(int i=N-1; i>=0; i--) {
			//int n1 = A[i];
			//int n2 = --count[n1]; // count[n1] = count[n1] - 1
			//B[n2] = n1;
			B[--count[A[i]]] = A[i];
		}
		return B;
	}
	public static void main(String[] args) {
		int A[] = {2, 1, 0, 5, 1, 2, 3};
		int k = 5;
		System.out.println("Unsorted: "+Arrays.toString(A));
		int B[] = new CountingSort().countingSort(A, k);
		System.out.println("Sorted: "+Arrays.toString(B));
	}
}
