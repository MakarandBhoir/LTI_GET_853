package chapter2.task;

import java.util.Arrays;

public class T1_CyclicRotation {
	public int[] solution(int[] A, int K) {// K = 3
		int temp;
		if(A != null && A.length > 0)
		{
			for(int i=1; i<=K; i++) {// i = 1
				temp = A[A.length-1]; //temp = 6, 7
				
				for(int j=A.length-1; j>0; j--) {// j = 4, 3, 2, 1, 0
					A[j] = A[j-1];
				}
				A[0] = temp;
			}
		}
		return A;
	}
	public static void main(String[] args) {
		int A[] = {3, 8, 9, 7, 6};//    6 3 8 9 7, 7 6 3 8 9
		//int A[] = {};
		int K = 3;
		A = new T1_CyclicRotation().solution(A, K);
		
		System.out.println(Arrays.toString(A));
	}

}
