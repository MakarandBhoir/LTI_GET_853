package chapter2.task;

public class T2_OddOccurance {
	public int solution(int A[]) {
		if(A.length == 0) {
			return -1;
		}
		int unpaired;
		unpaired = A[0];
		
		for(int i=1; i<A.length; i++) {
			unpaired = unpaired ^ A[i];
		}
		return unpaired;
	}
	public static void main(String[] args) {
		int A[] = {9, 3, 9, 3, 9, 7, 7};
		System.out.println("Unpaired: "+new T2_OddOccurance().solution(A));
	}
}
