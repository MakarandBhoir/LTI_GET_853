package chapter2.basics;

public class L2_ArraysBasic1 {
	public int negative(int temp[]){
		   int N = temp.length;
		   int days = 0;
		   for(int i=0; i<N; i++){
		      if(temp[i] < 0)
		           days += 1;
		   }
		   return days;
		}
	public int negative2(int temp[]){
		  int days = 0;
		   for(int day : temp)
			   if(day < 0)
				   days += 1;
		   return days;
		}
	public static void main(String[] args) {
		int temp[] = new int[7];
		temp[0] = 13;
		temp[1] = 20;
		temp[2] = -3;
		temp[3] = 33;
		temp[4] = 23;
		temp[5] = -2;
		temp[6] = 27;
		
		int reuslt = new L2_ArraysBasic1().negative2(temp);
		System.out.println("Days with negative temprature: "+reuslt);
	}
}
