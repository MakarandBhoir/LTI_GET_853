package chapter2.basics;

public class L2_ArraysBasic2 {
	public int[] reverse(int A[]) { // 27 20 -3 33 23 -2 13
		int N = A.length; // 7
		for (int i = 0; i < N / 2; i++) { // 7 / 2 = 3
			int k = N - i - 1; // 7 - 0 - 1=6
			A[i] = A[i] + A[k];// 13 + 27 = 40
			A[k] = A[i] - A[k];// 40 - 27 = 13
			A[i] = A[i] - A[k];// 40 - 13 = 27
		}
		return A;
	}
	// this method will print the array as it is
	public void iterate(int []temp) {
		for(int t: temp)
			System.out.print(t+" ");
		System.out.println();
	}

	public static void main(String[] args) {
		int A[] = new int[7];
		A[0] = 13;
		A[1] = 20;
		A[2] = -3;
		A[3] = 33;
		A[4] = 23;
		A[5] = -2;
		A[6] = 27;
		L2_ArraysBasic2 obj = new L2_ArraysBasic2();
		obj.iterate(A);
		A = obj.reverse(A);
		obj.iterate(A);
	}

}
