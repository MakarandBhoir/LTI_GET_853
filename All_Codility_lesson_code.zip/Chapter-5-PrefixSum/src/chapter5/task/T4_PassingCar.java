package chapter5.task;

public class T4_PassingCar {
	public int solution(int A[]) {
		int MAX_LIMIT = 1000000000;
		int eastCount = 0;
		int passing = 0;
		for (int car : A) {
			if (car == 1) {
				passing = passing + eastCount;
			} else {
				eastCount++;
			}
		}
		if (passing > MAX_LIMIT || passing < 0)
			return -1;
		return passing;
	}
	// Arijit
	public int solution2(int A[]) { // A[] = {0, 1, 0, 1, 1};
		int passing = 0, n = A.length;// s = 0, n = 5
		int[] p = new int[n]; // P[] = {0, 1, 1, 2, 3}
		p[0] = A[0];
		for (int i = 1; i < n; i++) {
			p[i] = p[i - 1] + A[i];
		}
		for (int i = 0; i < n; i++) {//i = 0, 1, 2, 3, 4, 5
			if (A[i] == 0) {
				passing += p[n - 1] - p[i];// s = 3, s = 3 + 2 = 5
			}
			if (passing > 1000000000)
				return -1;
		}
		return passing;
	}

	public static void main(String[] args) {
		 //int A[] = {0, 1, 0, 1, 1};
		int A[] = { 0, 0, 0, 1, 1 };
		System.out.println(new T4_PassingCar().solution2(A));
	}
}
