package chapter1.task;

public class T1_Solution3 {
	public int solution(int N) {
		int max = 0;
		int counter = 0;
		boolean isCounting = false;
		while(N > 0) {
			if((N & 1) == 1) {
				if(isCounting) {
					max = Math.max(max, counter);
					counter = 0;
				}else {
					isCounting = true;
				}
			}else {
				if(isCounting) {
					counter++;
				}
			}
			N = N >> 1;
		}
		return max;
	}
	public static void main(String[] args) {
		System.out.println("Binary Gap: "+new T1_Solution3().solution(1041));
	}
}
