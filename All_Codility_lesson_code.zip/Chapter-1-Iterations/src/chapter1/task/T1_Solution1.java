package chapter1.task;

/* As per Codility Correctness of this solution is 46% */
public class T1_Solution1 {
	public int solution(int N) {
		String s = Integer.toBinaryString(N);
		long binary = Long.parseLong(s); // --> 1001
		boolean isCounting = false;
		int max = 0;
		int counter = 0;
		
		while(binary > 0) { 
			long rem = binary % 10; 
			if(rem == 1) {
				if(isCounting) {
					max = Math.max(max, counter);
					counter = 0;
				}else {
					isCounting = true;
					//counter = 0;
				}
			}else {
				if(isCounting) {
					counter++;
				}
			}
			binary = binary / 10; 
		}
		return max;		
	}
	public static void main(String[] args) {
		T1_Solution1 obj = new T1_Solution1();
		System.out.println("Binary Gap: "+obj.solution(9));
	}

}
