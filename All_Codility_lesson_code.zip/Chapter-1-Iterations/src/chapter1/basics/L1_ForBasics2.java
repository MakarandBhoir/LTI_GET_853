package chapter1.basics;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class L1_ForBasics2 {
	public static void mapIteration(Map<String, String> days) {
		Set<String> keys = days.keySet(); //["mon", "tue", "wed", "thu"...]
		for(String day : keys) {
			System.out.println(day+" stands for "+days.get(day)); // days.get("tue") -> Tuesday
		}
	}
	public static void main(String[] args) {
		Map<String, String> mapDays = new HashMap<>();
		mapDays.put("mon", "Monday");
		mapDays.put("tue", "Tuesday");
		mapDays.put("wed", "Wednesday");
		mapDays.put("thu", "Thusday");
		mapDays.put("fri", "Friday");
		mapDays.put("sat", "Saturday");
		mapDays.put("sun", "Sunday");
		mapIteration(mapDays);
	}
}
