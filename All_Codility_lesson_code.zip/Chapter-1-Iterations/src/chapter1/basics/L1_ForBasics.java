package chapter1.basics;

public class L1_ForBasics {
	public static long factorial(int num) {
		long fact = 1;
		for(int i=1; i<=num; i++) {
			fact = fact * i;
		}
		return fact;
	}
	
	public static long sum(int num) {
		long sum = 0;
		for(int i=1; i<=num; i++) {
			sum = sum + i;
		}
		return sum;
	}
	
	public static void design1(int num) {
		for(int i=1; i<=num; i++) {
			for(int j=1; j<=i; j++) {
				System.out.print(" * ");
			}
			System.out.println();
		}
	}
	public static void design2(int num) {
		for(int i=num;i>0;i--)  
        {  
            for(int j=i;j<=num;j++)  
            {  
                System.out.print(" ");  
            }  
            for(int j=1;j<=i;j++)  
            {  
                System.out.print("*"+" ");  
            }  
            System.out.println("");  
        }
	}
	public static void main(String[] args) {
		//System.out.println("Factorial: "+factorial(20));
		//design1(15);
		design2(5);
	}
}
