package chapter7.basic;

public class QueueDemo {
	private static int size=7, front = -1, rear = -1;//size=7, front = -1, 0, 1, rear = -1, 0, 1, 2
	private static int arr[] = new int[size]; // arr = [100, 200, 300, 0, 0, 0, 0]
	
	private static void enqueue(int item) {// item = 100, 200
		if (rear == (size - 1)) {
			System.out.println("Queue is full.");
		} else {
			rear = rear + 1;
			arr[rear] = item;
			System.out.println("Element " + item + " added into queue.");
		}
	}
	private static void dequeue() {
		if (front == -1 && rear == -1) {
			System.out.println("Queue is empty.");
		} else if (front == rear) {
			System.out.println("Queue is empty.");
		} else {
			front++;
			int item = arr[front];
			System.out.println(item + " removed from queue.");
		}
	}
	public static void main(String[] args) {
		enqueue(100);
		enqueue(200);
		enqueue(300);
		
		dequeue();
		dequeue();
		dequeue();
		dequeue();
		
	}

}
