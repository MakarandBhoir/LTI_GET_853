package chapter7.basic;

public class StackDemo {
	private static int size = 5, top = -1;
	private static int arr[] = new int[size];

	public static void push(int n) {
		if (top == size - 1) {
			System.out.println("Stack Overfolw");
		} else {
			top = top + 1;
			arr[top] = n;
		}
	}
	public static int pop() {
		if (top == -1) {
			System.out.println("Stack Underflow");
			return -1;
		} else {
			int n = arr[top];
			top = top - 1;
			return n;
		}
	}
	public static void main(String[] args) {
		push(10); //top = 0
		push(20); //top = 1
		push(30);
		push(40);
		push(50); //top = 4
		System.out.println(pop()); // top = 3
		push(60); // top = 4
		push(70); // top = 4
		System.out.println(pop());
	}
}
