package chapter7.basic;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueDemo2 {
	public static void main(String[] args) {
		Queue<Integer> queue = new PriorityQueue<>();
		
		queue.add(100);
		queue.add(200);
		
		System.out.println(queue.poll());
		System.out.println(queue.peek());
		
		System.out.println(queue);
	}
}
