package chapter7.task;

import java.util.Stack;

public class T3_Nested {
	public int solution(String S) {
		Stack<Character> s = new Stack<>();
		// S = (())
		for (Character i : S.toCharArray()) { // ['(' '(' ')' ')']
			if (i == '(')
				s.push(i);
			else if (!s.isEmpty())
				s.pop();
			else
				return 0;
		}
		return !s.isEmpty() ? 0 : 1;
	}

	public int solution2(String S) {
		int tmp = 0;
		for (Character i : S.toCharArray()) {
			if (i == '(')
				tmp++;
			else
				tmp--;
			if (tmp < 0)
				return 0;
		}
		if (tmp == 0)
			return 1;
		return 0;
	}

	public static void main(String[] args) {

	}

}
