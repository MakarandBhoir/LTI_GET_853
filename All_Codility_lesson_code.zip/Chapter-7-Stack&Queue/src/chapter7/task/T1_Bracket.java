package chapter7.task;

import java.util.Arrays;
import java.util.List;
import java.util.Stack;

public class T1_Bracket {
	public int solution(String str) {
		// Initialize open and close paranthesis list
		List<Character> open = Arrays.asList('(', '{', '[');
		List<Character> close = Arrays.asList(')', '}', ']');

		// Initialize a stack of character
		Stack<Character> stack = new Stack<Character>();

		// Process each bracket of expression one at a time
		for (int i = 0; i < str.length(); i++) {
			char ch = str.charAt(i);
			// If we encounter opening bracket we pushed into the stack and move to ahead
			if (open.contains(ch)) {
				stack.push(ch);
			} else if(close.contains(ch) && !stack.isEmpty()) {
				// If the element on the top of the stack is opening bracket of the same type 
				// then we peek that element into the top
				Character top = stack.peek();
				// Then we match top with current char index. 
				// And if match found then we pop that closing bracket
				// otherwise return 0
				if (open.indexOf(top) == close.indexOf(ch)){
					stack.pop();
				}else {
					return 0;
				}
			}else {
				return 0;
			}
		}
		return stack.isEmpty() ? 1 : 0;
	}

	public static void main(String[] args) {
		String S = "{()}[]]";
		System.out.println(new T1_Bracket().solution(S));
	}
}
