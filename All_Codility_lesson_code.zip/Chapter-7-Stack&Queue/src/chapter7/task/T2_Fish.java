package chapter7.task;

import java.util.Stack;

public class T2_Fish {
	public int solution(int A[], int B[]) { // { 4, 3, 2, 1, 5 };
											// { 0, 1, 0, 0, 0 }
		// special case: no fish
		if (A.length == 0)
			return 0;

		// main idea: use "stack" to store the fishes with B[i]==1
		// that is, "push" the downstream fishes into "stack"
		// note: "push" the Size of the downstream fish
		Stack<Integer> st = new Stack<>();
		int numAlive = A.length; // 5

		for (int i = 0; i < A.length; i++) {// i=0, 1, 2, 3, 4, 5
			// case 1; for the fish going to downstrem
			// push the fish to "stack", so we can keep them from the "last" one
			if (B[i] == 1) { //false, true, false, false
				st.push(A[i]); // push the size of the downstream fish
			}
			// case 2: for the fish going upstream
			// check if there is any fish going to downstream
			else if (B[i] == 0) {
				while (!st.isEmpty()) {
					// if the downstream fish is bigger (eat the upstream fish)
					if (st.peek() > A[i]) {
						numAlive--; // 4, 3
						break; // the upstream fish is eaten (ending)
					}
					// if the downstream fish is smaller (eat the downstream fish)
					else if (st.peek() < A[i]) {
						numAlive--; // 2
						st.pop(); // the downstream fish is eaten (not ending)
					}
				}
			}
		}
		return numAlive;
	}

	public static void main(String[] args) {
		int[] A = new int[] { 4, 3, 2, 1, 5 };
		int[] B = new int[] { 0, 1, 0, 0, 0 };
		System.out.println(new T2_Fish().solution(A, B));

	}
}
