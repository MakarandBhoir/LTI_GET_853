package test;

import java.io.IOException;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
@WebServlet("/LifecycleServlet")
public class LifecycleServlet implements Servlet {

    public LifecycleServlet() {
    }
    
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init method called.");
		
		//getServletInfo();
	}
	
	public void destroy() {
		System.out.println("destroy method called.");
	}
	
	public ServletConfig getServletConfig() {
		System.out.println("getServletConfig method called.");
		return null;
	}
	
	public String getServletInfo() {
		System.out.println("getServletInfo method called.");
		return null; 
	}
	
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		System.out.println("service method called.");
	}
}
