package com.lti.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/process.do")
public class ProcessRequestServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fname = request.getParameter("fname");
		String lname = request.getParameter("lname");
		String email = request.getParameter("email");
		String city = request.getParameter("city");
		String gender = request.getParameter("gender");
		
		PrintWriter pw = response.getWriter();
		response.setContentType("text/html");
		
		pw.println("<Html>");
		pw.println("<Body>");
		pw.println("<Table border='1'>");
		pw.println("<tr>");
		
		pw.println("<td>"+fname+"</td>");
		pw.println("<td>"+lname+"</td>");
		pw.println("<td>"+city+"</td>");
		pw.println("<td>"+email+"</td>");
		pw.println("<td>"+gender+"</td>");
		
		pw.println("</tr>");
		pw.println("</Table>");
		pw.println("</Body>");
		pw.println("</Html>");
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
