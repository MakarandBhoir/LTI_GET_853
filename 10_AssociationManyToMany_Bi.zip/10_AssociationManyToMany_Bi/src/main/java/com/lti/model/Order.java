package com.lti.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name="ORDER_TBL")
public class Order implements Serializable {
	@Id
	@Column(name="ORDER_ID")
	private long orderId;
	
	@Column(name="ORDER_DATE")
	@Temporal(TemporalType.DATE)
	private Date orderDate;
	
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="ORDER_PRODUCT_MAPPING", 
		joinColumns= {@JoinColumn(name="Order_Id")}, 
		inverseJoinColumns= { @JoinColumn(name="Product_Id") }
	)
	private Set<Product> products;
	
	public Order() {
		
	}
	public Order(long orderId, Date orderDate) {
		super();
		this.orderId = orderId;
		this.orderDate = orderDate;
	}
	
	public void addProduct(Product product){
		products.add(product);
	}

	
	public long getOrderId() {
		return orderId;
	}
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", orderDate=" + orderDate + "]";
	}
	public Set<Product> getProducts() {
		return products;
	}
	public void setProducts(Set<Product> products) {
		this.products = products;
	}
}
