package com.lti.ui;

import java.util.Date;
import java.util.HashSet;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.model.Order;
import com.lti.model.Product;

public class Main {
	public static void main(String[] args) {
		EntityManagerFactory factory =  Persistence.createEntityManagerFactory("JPA_PU");
		EntityManager entityManager = factory.createEntityManager();
		
		Product elecProduct = new Product();
		elecProduct.setProductId(1);
		elecProduct.setProductName("LED TV");

		Product beautyProduct = new Product();
		beautyProduct.setProductId(2);
		beautyProduct.setProductName("Face Wash");

		Product babyProduct = new Product();
		babyProduct.setProductId(3);
		babyProduct.setProductName("Pampers");

		Product eleProduct = new Product();
		eleProduct.setProductId(4);
		eleProduct.setProductName("CFL Bulb");

		// now define first order and add few products in it
		Order firstOrder = new Order();
		firstOrder.setOrderId(1000);
		firstOrder.setOrderDate(new Date());
		firstOrder.setProducts(new HashSet<Product>());
		
		firstOrder.addProduct(elecProduct);
		firstOrder.addProduct(beautyProduct);
		firstOrder.addProduct(babyProduct);
		
		// now define second order and add few products in it
		Order secondOrder = new Order();
		secondOrder.setOrderId(1001);
		secondOrder.setOrderDate(new Date());
		secondOrder.setProducts(new HashSet<Product>());
		
		
		secondOrder.addProduct(beautyProduct);
		secondOrder.addProduct(babyProduct);
		
		entityManager.getTransaction().begin();
		entityManager.persist(firstOrder);
		entityManager.persist(secondOrder);
		entityManager.getTransaction().commit();
	}
}
