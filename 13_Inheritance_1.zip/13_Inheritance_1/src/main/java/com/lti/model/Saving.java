package com.lti.model;

public class Saving extends Account {
	private double roi;
	
}
