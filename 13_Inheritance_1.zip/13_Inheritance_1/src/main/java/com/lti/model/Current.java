package com.lti.model;

public class Current extends Account {
	private double overdraft;
	
}
