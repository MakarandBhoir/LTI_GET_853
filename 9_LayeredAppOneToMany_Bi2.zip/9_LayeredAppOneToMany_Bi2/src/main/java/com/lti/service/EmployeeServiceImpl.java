package com.lti.service;

import java.util.List;

import com.lti.dao.EmployeeDaoImpl;
import com.lti.model.Employee;

public class EmployeeServiceImpl {
	private EmployeeDaoImpl dao = new EmployeeDaoImpl();
	
	public List<Employee> findEmployeesByDeptId(int deptId){
		return dao.readEmployeesByDeptId(deptId);
	}
	
	public List<Employee> findEmployeeWithDepartmentName(){
		return dao.readEmployeeWithDepartmentName();
	}
}
