package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.lti.model.Employee;
import com.lti.util.JpaUtility;

public class EmployeeDaoImpl {
	private EntityManager entityManager;

	public EmployeeDaoImpl() {
		entityManager = JpaUtility.getEntityManager();
	}
	
	public List<Employee> readEmployeesByDeptId(int deptId) {
		// String sql = "Select * From Employee_tbl where dept_id=:deptId";
		String jpql = "Select e From Employee e where e.department.departmentId=:deptId";
		TypedQuery<Employee> tquery = entityManager.createQuery(jpql, Employee.class);
		tquery.setParameter("deptId", deptId);
		return tquery.getResultList();
	}
	
	public List<Employee> readEmployeeWithDepartmentName(){
		//String sql = Select e.employeeId, e.employeeName, e.salary, d.departmentName From Employee e, Department d where e.dept_id = d.dept_id
		String jpql = "Select e From Employee e";
		TypedQuery<Employee> tquery = entityManager.createQuery(jpql, Employee.class);
		List<Employee> list = tquery.getResultList();
		return list;
	}

	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	public void rollbackTransaction() {
		entityManager.getTransaction().rollback();
	}
}
