package com.lti.ui;

import java.util.List;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import com.lti.model.Department;
import com.lti.model.Employee;

public class Main2 {
	public static void main(String[] args) {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA_PU");
		EntityManager entityManager = factory.createEntityManager();
		//Department dept = entityManager.find(Department.class, 10);
		
		TypedQuery<Department> tquery = entityManager.createQuery("Select d From Department d", Department.class);
		List<Department> deptList = tquery.getResultList();
		
		for(Department d : deptList) {
			System.out.println("Department Id: "+d.getDepartmentId());
			System.out.println("Department Name: "+d.getDepartmentName());
			for(Employee emp : d.getEmployees()) {
				System.out.println("Employee Id: "+emp.getEmployeeId());
				System.out.println("Employee Name: "+emp.getEmployeeName());
				System.out.println("Employee Salary: "+emp.getEmployeeSalary());
			}
		}
		
		TypedQuery<Employee> tquery2 = entityManager.createQuery("Select e From Employee e where e.department.departmentId=10", Employee.class);
		List<Employee> emps = tquery2.getResultList();
		for(Employee e : emps) {
			System.out.println("Employee Id: "+e.getEmployeeId());
			System.out.println("Employee Name: "+e.getEmployeeName());
			System.out.println("Employee Salary: "+e.getEmployeeSalary());
			System.out.println("Department Name: "+e.getDepartment().getDepartmentName());
		}
	}
}
