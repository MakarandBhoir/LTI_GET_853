package com.lti.ui;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.lti.model.Department;
import com.lti.model.Employee;

public class Main {
	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA_PU");
		EntityManager entityManager = factory.createEntityManager();
		
	
		Department department = new Department(10, "Development");
		
		Employee employee1 = new Employee(100, "Makarand", 5000);
		employee1.setDepartment(department);
		
		Employee employee2 = new Employee(101, "Turesh", 7000);
		employee2.setDepartment(department);
		
		Set<Employee> employees = new HashSet<>();
		employees.add(employee1);
		employees.add(employee2);
		
		department.setEmployees(employees);
		
		entityManager.getTransaction().begin();
		entityManager.persist(department);	
		entityManager.getTransaction().commit();
	}
}
