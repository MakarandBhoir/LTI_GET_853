package com.lti.ui;

import java.util.List;

import com.lti.model.Employee;
import com.lti.service.EmployeeServiceImpl;

public class Main3 {
	public static void main(String[] args) {
		EmployeeServiceImpl service = new EmployeeServiceImpl();
		
		List<Employee> employees = service.findEmployeeWithDepartmentName();
		for(Employee emp : employees) {
			System.out.println("Employee Id: "+emp.getEmployeeId());
			System.out.println("Employee Name: "+emp.getEmployeeName());
			System.out.println("Employee Salary: "+emp.getEmployeeSalary());
			System.out.println("Department Name: "+emp.getDepartment().getDepartmentName());
			System.out.println("--------------------------------------------------------");
		}
	}
}
