package com.lti;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.lti.model.Employee;
import com.lti.service.EmployeeServiceImpl;

// http://localhost:9090/RestEmployee/rest/employees
@Path("employees")
public class EmployeeResource {
	EmployeeServiceImpl service = new EmployeeServiceImpl();
	
	public void addEmployee(Employee employee) {
		service.addEmployee(employee);
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Employee> getAllEmployees(){
		return service.findAllEmployees();
	}
}
