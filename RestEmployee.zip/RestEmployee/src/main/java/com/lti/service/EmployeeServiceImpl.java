package com.lti.service;

import java.util.List;

import com.lti.dao.EmployeeDaoImpl;
import com.lti.model.Employee;

public class EmployeeServiceImpl {
	EmployeeDaoImpl dao = new EmployeeDaoImpl();
	
	public boolean addEmployee(Employee employee) {
		int result = dao.createEmployee(employee);
		return (result == 1) ? true : false;
	}
	
	public List<Employee> findAllEmployees() {
		List<Employee> list = dao.readAllEmployee();
		return list;
	}
}
