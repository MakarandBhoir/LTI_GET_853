import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-like-dislike',
  template: `<h1>Angular LikeDislike</h1>
  <button [ngClass]=" {'liked':getLiked() }" (click)="likeCounter()">Like | {{like}}</button>
  <button [ngClass]=" {'disliked':getDisliked() }" (click)="dislikeCounter()">Dislike | {{dislike}}</button>
  `,
  styles: [`
    .liked, .disliked{
      color: blue;
    }
  `]
})
export class LikeDislikeComponent {
  like: number = 100;
  dislike: number = 25;

  liked: boolean = false;
  disliked: boolean = false;

  likeCounter() {
    if (!this.liked) {
      this.like++;
      this.liked = true;
    } else {
      this.like--;
      this.liked = false;
    }
  }

  dislikeCounter() {
    if (!this.disliked) {
      this.dislike++;
      this.disliked = true;
    } else {
      this.dislike--;
      this.disliked = false;
    }
  }

  getLiked(){
    return this.liked;
  }
  getDisliked(){
    return this.disliked;
  }
}