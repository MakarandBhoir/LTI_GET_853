package com.lti.service;

import java.util.List;

import com.lti.model.Author;
import com.lti.model.Book;

public interface BookService {
	public List<Book> findAllBooks();
	public List<Book> findBooksByAuthorName(String authorName);
	public List<Book> findBooksByPrice(double min, double max);
	public List<Author> findAuthorByBookId(long isbn);
}
