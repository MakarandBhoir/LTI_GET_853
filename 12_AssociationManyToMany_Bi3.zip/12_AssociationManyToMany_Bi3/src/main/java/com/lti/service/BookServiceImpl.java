package com.lti.service;

import java.util.List;

import com.lti.dao.BookDao;
import com.lti.dao.BookDaoImpl;
import com.lti.model.Author;
import com.lti.model.Book;

public class BookServiceImpl implements BookService{
	private BookDao dao = new BookDaoImpl();
	
	@Override
	public List<Book> findAllBooks() {
		return dao.readAllBook();
	}

	@Override
	public List<Book> findBooksByAuthorName(String authorName) {
		return dao.readBooksByAuthorName(authorName);
	}

	@Override
	public List<Book> findBooksByPrice(double min, double max) {
		return dao.readBooksByPrice(min, max);
	}

	@Override
	public List<Author> findAuthorByBookId(long isbn) {
		return dao.readAuthorByBookId(isbn);
	}
}
