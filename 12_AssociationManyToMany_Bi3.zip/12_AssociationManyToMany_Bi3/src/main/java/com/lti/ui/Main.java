package com.lti.ui;

import java.util.List;

import com.lti.model.Book;
import com.lti.service.BookService;
import com.lti.service.BookServiceImpl;

public class Main {
	public static void main(String[] args) {
		BookService service = new BookServiceImpl();
		
		System.out.println("All Books: ");
		List<Book> allBooks = service.findAllBooks();
		for(Book book : allBooks) {
			System.out.println(book);
		}
		System.out.println("-------------------------------------------");
		
		System.out.println("All book by price range: ");
		List<Book> allBooks2 = service.findBooksByPrice(250, 350);
		for(Book book : allBooks2) {
			System.out.println(book);
		}
	}
}
