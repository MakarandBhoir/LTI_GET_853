package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.lti.model.Author;
import com.lti.model.Book;
import com.lti.util.JpaUtility;


public class BookDaoImpl implements BookDao{
	private EntityManager entityManager;
	public BookDaoImpl() {
		entityManager = JpaUtility.getEntityManager();
		loadData();
	}
	
	private void loadData() {
		Book book1 = new Book(1234567890, "Java Volume-I", 320.50);
		Book book2 = new Book(1876543210, "Cricket Memories", 400.0);
		
		Author author1 = new Author(1, "Cay Horstman");
		Author author2 = new Author(2, "Martin Guptil");
		
		book1.addAuthor(author1);
		
		book2.addAuthor(author2);
		book2.addAuthor(author1);
		
		entityManager.getTransaction().begin();
		entityManager.persist(book1);
		entityManager.persist(book2);
		entityManager.getTransaction().commit();
	}
	
	@Override
	public List<Book> readAllBook() {
		TypedQuery<Book> tquery = entityManager.createNamedQuery("findAllBooks", Book.class);
		return tquery.getResultList();
	}

	@Override
	public List<Book> readBooksByAuthorName(String authorName) {
		return null;
	}

	@Override
	public List<Book> readBooksByPrice(double min, double max) {
		TypedQuery<Book> tquery = entityManager.createNamedQuery("findBooksByPrice", Book.class);
		tquery.setParameter("min", min);
		tquery.setParameter("max", max);
		return tquery.getResultList();
	}

	@Override
	public List<Author> readAuthorByBookId(long isbn) {
		return null;
	}

}
