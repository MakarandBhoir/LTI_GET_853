package com.lti.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
@Entity
@NamedQueries({
	@NamedQuery(name="findAllBooks", query="Select b From Book b"),
	@NamedQuery(name="findBooksByPrice", query="Select b From Book b Where b.price between :min And :max")
})
public class Book implements Serializable{
	@Id
	private long isbn;
	private String title;
	private double price;
	@ManyToMany(cascade=CascadeType.ALL)
	@JoinTable(name="Book_Author", 
			joinColumns={@JoinColumn(name="book_isbn")},
			inverseJoinColumns={@JoinColumn(name="author_id")})
	private
	Set<Author> authors = new HashSet<>();
	public Book(){
	}
	public Book(long isbn, String title, double price) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
	}
	public void addAuthor(Author author){
		getAuthors().add(author);
	}
	public long getIsbn() {
		return isbn;
	}
	public void setIsbn(long isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price + "]";
	}
	public Set<Author> getAuthors() {
		return authors;
	}
	public void setAuthors(Set<Author> authors) {
		this.authors = authors;
	}
}
