export class Address{
    city:string;
    state:string;
    pin:string;

    constructor(city:string, state:string, pin:string){
        this.city = city;
        this.state = state;
        this.pin = pin;
    }
}