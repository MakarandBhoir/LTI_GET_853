import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Address } from '../address';
import { Student } from '../student';
import { StudentService } from '../student.service';

@Component({
  selector: 'add-student',
  templateUrl: './add-student.component.html',
  styleUrls: ['./add-student.component.css']
})
export class AddStudentComponent implements OnInit {
  studentForm: FormGroup;
  students: Student[];

  constructor(private fb: FormBuilder, private service:StudentService) {
       this.students = new Array();
  }

  ngOnInit() {
    this.studentForm = this.fb.group({
      studentId: ['', Validators.required],
      studentName: ['', Validators.required],
      score: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      pin: ['', Validators.required],
      
    });

    this.service.getAllStudents().subscribe(data=>{
         this.students = data;
    });
  }
  
  addStudent(): void {
    let address:Address = new Address(this.studentForm.controls.city.value, 
      this.studentForm.controls.state.value, this.studentForm.controls.pin.value);

    let student:Student = new Student(this.studentForm.controls.studentId.value, 
      this.studentForm.controls.studentName.value, 
      this.studentForm.controls.score.value, address);

      this.service.addStudent(student).subscribe(data => {
        this.students.push(student);
      })
  }
}
