import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Student } from './student';

@Injectable({
  providedIn: 'root'
})
export class StudentService {

  basePath:string = "http://localhost:9091/StudentApp/students/";

  constructor(private http:HttpClient) { 
  }

  addStudent(student:Student):Observable<Object>{
    return this.http.post(this.basePath, student);
  }
  getAllStudents():Observable<Student[]>{
    // the result of get function. get fun will give you Observable<Student[]>
    return this.http.get<Student[]>(this.basePath);
  }

}
