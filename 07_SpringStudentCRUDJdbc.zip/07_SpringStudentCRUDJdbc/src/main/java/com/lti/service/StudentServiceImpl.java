package com.lti.service;

import java.util.List;

import com.lti.dao.StudentDao;
import com.lti.model.Student;

public class StudentServiceImpl implements StudentService{
	//StudentDaoImpl dao = new StudentDaoImpl();
	//StudentDao dao = new StudentDaoImpl();
	
	// Object will be created by spring framework & will be injected here
	private StudentDao dao = null;
	
	@Override
	public boolean addStudent(Student student) {
		int result = getDao().createStudent(student);
		return (result == 1)? true : false;
	}

	@Override
	public List<Student> findAllStudents() {
		return getDao().readAllStudents();
	}
	public StudentDao getDao() {
		return dao;
	}
	public void setDao(StudentDao dao) {
		this.dao = dao;
	}

}
