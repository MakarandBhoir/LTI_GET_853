package com.lti.dao;

import java.util.ArrayList;
import java.util.List;

import com.lti.model.Student;

public class StudentDaoImpl implements StudentDao{
	private static List<Student> inMemoryDB = new ArrayList<>();
	
	@Override
	public int createStudent(Student student) {
		boolean result = inMemoryDB.add(student);
		return (result) ? 1 : 0;
	}

	@Override
	public List<Student> readAllStudents() {
		return inMemoryDB;
	}

}
