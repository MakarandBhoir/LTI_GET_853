package com.lti.model;

public class Student {
	private int studentId;
	private String studentName;
	private double score;
	
	private Address address;// = new Address("Mumbai", "MH", "400706");
	
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	public void showAddress() {
		System.out.println(address);
	}
	public void showStudent() {
		System.out.println("Student Id: "+studentId);
		System.out.println("Student Name: "+studentName);
		System.out.println("Score: "+score);
		showAddress();
	}
	public Student() {
		
	}
	
	public Student(int studentId, String studentName, double score) {
		super();
		this.studentId = studentId;
		this.studentName = studentName;
		this.score = score;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public double getScore() {
		return score;
	}
	public void setScore(double score) {
		this.score = score;
	}
	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentName=" + studentName + ", score=" + score
				+ "]";
	}
}
