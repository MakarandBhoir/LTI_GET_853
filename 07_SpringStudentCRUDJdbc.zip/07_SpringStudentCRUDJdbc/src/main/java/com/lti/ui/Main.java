package com.lti.ui;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.lti.model.Student;
import com.lti.service.StudentService;

public class Main {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("spring-config.xml");
		
		StudentService service = context.getBean("service", StudentService.class);
		Student student = context.getBean("student", Student.class);
		student.setStudentId(20);
		
		boolean result = service.addStudent(student);
		if(result) {
			System.out.println("Student is added.");
			/*
			 * List<Student> students = service.findAllStudents(); for(Student s : students)
			 * { System.out.println(s); }
			 */
		}
	}
}
