package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.lti.model.Student;
import com.lti.service.StudentService;

@Controller("studentController")
public class StudentController {
	//@Autowired
	//private Student student;
	@Autowired
	private ApplicationContext context;
	
	@Autowired
	private StudentService service;

	// http://localhost:9091/12_SpringMvcStudentJdbc/
	@RequestMapping(path = "/", method = RequestMethod.GET)
	public String home() {
		return "homeStudent";
	}

	// http://localhost:9091/12_SpringMvcStudentJdbc/addStudentForm.view
	@RequestMapping(path = "addStudentForm.view", method = RequestMethod.GET)
	public String addStudentForm() {
		return "addStudent";
	}

	// http://localhost:9091/12_SpringMvcStudentJdbc/addStudent.do

	@RequestMapping(path = "addStudent.do", method = RequestMethod.POST)
	public String addStudent(@RequestParam("studentId") int studentId, @RequestParam("studentName") String studentName,

			@RequestParam("studentScore") double studentScore, @RequestParam("city") String city,

			@RequestParam("state") String state, @RequestParam("pin") String pin) {

		Student student = context.getBean(Student.class);
		
		student.setStudentId(studentId);
		student.setStudentName(studentName);
		student.setScore(studentScore);
		student.getAddress().setCity(city);
		student.getAddress().setState(state);
		student.getAddress().setPin(pin);

		boolean result = service.addStudent(student);
		if (result) {
			// calling another controller method not the view
			return "redirect:viewStudent.do";
		} else
			return "error";
	}

	@RequestMapping(path = "viewStudent.do", method = RequestMethod.GET)
	public String getAllStudents(Model model) {
		List<Student> students = service.findAllStudents();
		model.addAttribute("studentList", students);
		return "viewStudent";
	}
}
