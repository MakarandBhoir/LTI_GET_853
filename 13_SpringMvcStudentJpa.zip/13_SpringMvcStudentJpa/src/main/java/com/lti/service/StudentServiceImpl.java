package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import com.lti.dao.StudentDao;
import com.lti.model.Student;

@Service("service")
@Scope(scopeName="singleton")
public class StudentServiceImpl implements StudentService{
	//StudentDaoImpl dao = new StudentDaoImpl();
	//StudentDao dao = new StudentDaoImpl();
	
	// Object will be created by spring framework & will be injected here
	@Autowired
	private StudentDao dao = null;
	
	@Override
	public boolean addStudent(Student student) {
		dao.beginTransaction();
		int result = dao.createStudent(student);
		dao.commitTransaction();
		return (result == 1)? true : false;
	}
	@Override
	public List<Student> findAllStudents() {
		return dao.readAllStudents();
	}
	@Override
	public boolean modifyStudent(Student student) {
		dao.beginTransaction();
		int result = dao.updateStudent(student);
		dao.commitTransaction();
		return (result == 1)? true : false;
	}
	@Override
	public boolean removeStudent(int studentId) {
		dao.beginTransaction();
		int result = dao.deleteStudent(studentId);
		dao.commitTransaction();
		return (result == 1)?true : false;
	}
}
