package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.lti.model.Student;
import com.lti.util.JpaUtility;
@Repository("dao")
public class StudentDaoImpl implements StudentDao{
	
	private EntityManager entityManager;
	
	public StudentDaoImpl() {
		entityManager = JpaUtility.getEntityManager();
	}
	
	@Override
	public int createStudent(Student student) {
		entityManager.persist(student);
		return 1;
	}
	@Override
	public List<Student> readAllStudents() {
		String jpql = "Select  s From Student s";
		TypedQuery<Student> tquery = entityManager.createQuery(jpql, Student.class);
		return tquery.getResultList();
	}
	@Override
	public int updateStudent(Student student) {
		student = entityManager.merge(student);
		return 1;
	}
	@Override
	public int deleteStudent(int studentId) {
		Student student = entityManager.find(Student.class, studentId);
		entityManager.remove(student);
		return 1;
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}

	@Override
	public void rollbackTransaction() {
		entityManager.getTransaction().rollback();
	}

}
