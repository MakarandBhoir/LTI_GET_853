Simple form which allow you to enter employee data.
And capture that data using FormGroup and FormControl and pass data to service
pass data using model object

Step1: Install Json Server
    npm install -g json-server
Step2: Run Json Server
    json-server --watch db.json
Step3: Test your json server on this
    http://localhost:3000

Step3: Run the app
    ng serve -o