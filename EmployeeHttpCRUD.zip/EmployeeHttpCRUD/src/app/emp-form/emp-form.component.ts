import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Form } from '@angular/forms';
import { EmpService } from '../emp.service';
import { Employee } from '../employee';
import { Router } from '@angular/router';

@Component({
  selector: 'app-emp-form',
  templateUrl: './emp-form.component.html',
  styleUrls: ['./emp-form.component.css']
})
export class EmpFormComponent implements OnInit {
  empForm: FormGroup;
  employees:Employee[]=new Array();

  constructor(private formBuilder:FormBuilder, private empService:EmpService, private router:Router) { 
  }

  ngOnInit() {
    this.empForm = this.formBuilder.group({
      firstName: ['Makarand'],
      lastName: ['Bhoir'],
      email:['bhoir.makarand@gmail.com']
    });
  }

  saveEmployee():void{
    this.empService.addEmployee(this.empForm.value).subscribe(data=>{
      this.router.navigate(['list-emp']);
    })
  }

  
}
