import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmpFormComponent } from './emp-form/emp-form.component';
import { ListEmpComponent } from './list-emp/list-emp.component';
import { UpdateEmpComponent } from './update-emp/update-emp.component';


const routes: Routes = [
  {path:'add-emp', component:EmpFormComponent},
  {path:'list-emp', component:ListEmpComponent},
  {path:'update-emp', component:UpdateEmpComponent},
  {path:'', component:EmpFormComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
