import { Injectable } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Employee } from './employee';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EmpService {
  baseUrl:string="http://localhost:3000/employees";
  constructor(private http:HttpClient) { }
  addEmployee(emp:Employee):Observable<Object>{
      return this.http.post(this.baseUrl, emp);
  }
  getAllEmployees():Observable<Employee[]>{
    return this.http.get<Employee[]>(this.baseUrl);
  }
  getEmployeeById(id:string):Observable<Object>{
    return this.http.get(this.baseUrl+"/"+id);
  }
  deleteEmployee(emp:Employee):Observable<Object>{
    return this.http.delete(this.baseUrl+"/"+emp.id);
  }
  updateEmployee(emp:Employee):Observable<Object>{
    return this.http.put(this.baseUrl+"/"+emp.id, emp);
  }
}
