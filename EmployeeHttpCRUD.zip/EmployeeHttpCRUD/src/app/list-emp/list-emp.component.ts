import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { EmpService } from '../emp.service';
import { Employee } from '../employee';

@Component({
  selector: 'app-list-emp',
  templateUrl: './list-emp.component.html',
  styleUrls: ['./list-emp.component.css']
})
export class ListEmpComponent implements OnInit {
  employees:Employee[];
  constructor(private service:EmpService, private router:Router) { }

  ngOnInit() {
    this.service.getAllEmployees().subscribe(data => {
      this.employees = data;
    });
  }

  update(emp:Employee){
    localStorage.removeItem("editEmpId");
    localStorage.setItem("editEmpId", emp.id.toString());
    this.router.navigate(['update-emp']);
  }
  delete(emp:Employee){
    let result = confirm("Do you want to delete this employee?");
    if(result){
      this.service.deleteEmployee(emp).subscribe(data => {
        this.employees = this.employees.filter(e => e !== emp);
      });
    }
  }
}
