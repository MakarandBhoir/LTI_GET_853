import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EmpService } from '../emp.service';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

@Component({
  selector: 'app-update-emp',
  templateUrl: './update-emp.component.html',
  styleUrls: ['./update-emp.component.css']
})
export class UpdateEmpComponent implements OnInit {
  empForm:FormGroup;
  constructor(private router:Router, private service:EmpService, private formBuilder:FormBuilder) { }

  ngOnInit() {
    let empId = localStorage.getItem("editEmpId");
    if(!empId){
      alert("Invalid Employee Id");
      this.router.navigate(['list-emp']);
      return;
    }
    this.empForm = this.formBuilder.group({
      id: [],
      firstName: ['', Validators.required],
      lastName: ['', Validators.required],
      email:['', Validators.required]
    });
    this.service.getEmployeeById(empId).subscribe(data=>{
      this.empForm.setValue(data);
    }, error =>{
      alert("Invalid Employee Id");
    });
  }
  updateEmployee(){
    this.service.updateEmployee(this.empForm.value).subscribe(data=>{
      this.router.navigate(['list-emp']);
    });
  }
}
