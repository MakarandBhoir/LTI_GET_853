import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HttpClient } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmpFormComponent } from './emp-form/emp-form.component';
import { EmpService } from './emp.service';
import { from } from 'rxjs';
import { ListEmpComponent } from './list-emp/list-emp.component';
import { UpdateEmpComponent } from './update-emp/update-emp.component';

@NgModule({
  declarations: [
    AppComponent,
    EmpFormComponent,
    ListEmpComponent,
    UpdateEmpComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [EmpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
